export interface AppPage {
  url: string;
  icon: { md: string; ios: string; };
  title: string;
}
